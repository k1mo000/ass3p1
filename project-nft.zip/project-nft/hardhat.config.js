require("@nomicfoundation/hardhat-toolbox");
require("hardhat-gas-reporter");

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.19",
  networks: {
    //здесь указываем все сети, с которыми будем работать
    bnbtestnet: {
      url: "https://cosmopolitan-bold-voice.bsc-testnet.quiknode.pro/ff3c01e9c59224797e863c4def3f833ace3a5994/", //RPC from my quicknode
      accounts: ["eb425a596e0dfaddfa1454f7ee1f9093d29989b6233f73109229d35e2be1bf06"],
      chainId: 97,
    },
  },
  etherscan: {
    apiKey: "NMQXJ9XIK8NXE2STIFH1KXESSC1VWG15DE", // your Etherscan API key
  },

};